module Main where
import SchemeParser
import System.Environment

main :: IO ()
main = getArgs >>= print . eval . readExpr . head